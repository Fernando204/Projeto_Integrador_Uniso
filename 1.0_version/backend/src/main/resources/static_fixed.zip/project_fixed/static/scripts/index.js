import { initializeClientes } from "../components/clientes/clientes.js";
import { initializeColaboradores } from "../components/colaboradores/colaboradores.js";
import { initializeDashboard } from "../components/dashboard/dashboard.js";
import { initializeRelatorios } from "../components/relatorios/relatorios.js";
import { initializeSales } from "../components/vendas/Sales.js";
import { initializeFinances } from "../components/finanças/finance.js";
import { initializeEstoque } from "../components/estoque/estoque.js";
import { initializeConfiguracoes, loadSavedTheme } from "../components/configuracoes/configuracoes.js";
import { ApiConnection } from "./classes/ApiConnection.js";

// Apply saved theme as early as possible
loadSavedTheme();

const apiConnection = new ApiConnection();
const userInfoModal = document.getElementById("user-info-modal");
const loginBt = document.getElementById("gotoLoginBt");
const contentBox = document.getElementById("site-content");
const changeButtons = document.querySelectorAll(".pageButton");
const userProfileButton = document.querySelector(".user-profile-button");
const notifyButton = document.querySelector(".notification-button");
const notifyContainer = document.querySelector(".notify-container");
const profileContainer = document.querySelector(".profile-container");
const navBar = document.getElementById("mainNavBar");
const sidebarToggleBtn = document.getElementById("sidebarToggleBtn");
const settingsNavBtn = document.getElementById("settingsNavBtn");
const mainHeader = document.getElementById("mainHeader");

let logged = false;

// =============================================
// SIDEBAR TOGGLE
// =============================================
let sidebarOpen = true;

function updateHeaderPosition() {
    if (mainHeader) {
        mainHeader.style.left = sidebarOpen
            ? "var(--sidebar-width)"
            : "var(--sidebar-collapsed-width)";
    }
    contentBox.style.marginLeft = sidebarOpen
        ? "var(--sidebar-width)"
        : "var(--sidebar-collapsed-width)";
}

sidebarToggleBtn.addEventListener("click", () => {
    sidebarOpen = !sidebarOpen;
    if (sidebarOpen) {
        navBar.classList.remove("sidebar-collapsed");
    } else {
        navBar.classList.add("sidebar-collapsed");
    }
    updateHeaderPosition();
});

// =============================================
// ACTIVE STATE
// =============================================
function setActiveButton(index) {
    changeButtons.forEach(btn => btn.classList.remove("active"));
    if (changeButtons[index]) changeButtons[index].classList.add("active");
}

// =============================================
// NAVIGATION
// =============================================
const redirectToLogin = () => {
    location.href = "Pages/loginPage.html";
};

const logout = async () => {
    try {
        await apiConnection.logout();
    } finally {
        redirectToLogin();
    }
};

const renderUserModal = (user) => {
    userInfoModal.innerHTML = `
        <div class="profile-modal-top">
            <p class="title"></p>
            <p class="modal-sub-title"></p>
        </div>
        <button id="logoutBtn" class="logout-btn">Logout</button>
    `;

    userInfoModal.querySelector(".title").textContent =
        `Bem-vindo, ${user.name.split(" ")[0]}`;

    userInfoModal.querySelector(".modal-sub-title").textContent =
        user.email;

    userInfoModal
        .querySelector("#logoutBtn")
        .addEventListener("click", logout);
};

const checkSession = async () => {
    try {
        const res = await apiConnection.sendGetRequest("/session");

        if (!res || !res.name || !res.email) {
            throw new Error("Sessão inválida");
        }

        renderUserModal(res);
        localStorage.setItem("user-data", JSON.stringify(res));
        logged = true;
        initializeMain();
    } catch {
        alert("sessão invalida");
        redirectToLogin();
    }
};
checkSession();

let profileCardOpened = false;
let notifyCardOpened = false;

function initializeMain() {
    if (!logged) {
        console.log("Não logado!");
        return;
    }

    contentBox.classList.remove("loading");

    const changePage = async (pageUrl) => {
        const res = await fetch(pageUrl);
        const html = await res.text();
        contentBox.innerHTML = html;
    };

    // Default page: dashboard
    changePage("components/dashboard/dashboard.html").then(() => {
        initializeDashboard(apiConnection);
    }).catch(e => { alert(e); });

    // Nav buttons
    changeButtons.forEach((bt, index) => {
        switch (index) {
            case 0:
                bt.addEventListener("click", () => {
                    setActiveButton(0);
                    changePage("components/dashboard/dashboard.html").then(() => {
                        initializeDashboard(apiConnection);
                    });
                });
                break;
            case 1:
                bt.addEventListener("click", () => {
                    setActiveButton(1);
                    changePage("components/finanças/finance.html").then(() => {
                        initializeFinances(apiConnection);
                    });
                });
                break;
            case 2:
                bt.addEventListener("click", () => {
                    setActiveButton(2);
                    changePage("components/vendas/sales.html").then(() => {
                        initializeSales(apiConnection);
                    });
                });
                break;
            case 3:
                bt.addEventListener("click", () => {
                    setActiveButton(3);
                    changePage("components/clientes/clientes.html").then(() => {
                        initializeClientes(apiConnection);
                    });
                });
                break;
            case 4:
                bt.addEventListener("click", () => {
                    setActiveButton(4);
                    changePage("components/estoque/estoque.html").then(() => {
                        initializeEstoque(apiConnection);
                    });
                });
                break;
            case 5:
                bt.addEventListener("click", () => {
                    setActiveButton(5);
                    changePage("components/relatorios/relatorios.html").then(() => {
                        initializeRelatorios();
                    });
                });
                break;
            case 6:
                bt.addEventListener("click", () => {
                    setActiveButton(6);
                    changePage("components/colaboradores/colaboradores.html").then(() => {
                        initializeColaboradores(apiConnection);
                    });
                });
                break;
        }
    });

    // Settings button (header)
    settingsNavBtn.addEventListener("click", () => {
        changePage("components/configuracoes/configuracoes.html").then(() => {
            initializeConfiguracoes();
        });
    });

    // Profile modal
    userProfileButton.addEventListener("click", (e) => {
        e.stopPropagation();
        if (!profileCardOpened) {
            profileContainer.classList.add("expand");
            profileCardOpened = true;
        } else {
            closeProfile();
        }
    });

    // Notification modal
    notifyButton.addEventListener("click", (e) => {
        e.stopPropagation();
        if (!notifyCardOpened && notifyContainer) {
            notifyContainer.classList.add("expand");
            notifyCardOpened = true;
        } else {
            closeNotifications();
        }
    });

    document.addEventListener("click", (e) => {
        if (
            profileCardOpened &&
            !profileContainer.contains(e.target) &&
            !userProfileButton.contains(e.target)
        ) {
            closeProfile();
        }

        if (
            notifyCardOpened &&
            !notifyContainer.contains(e.target) &&
            !notifyButton.contains(e.target)
        ) {
            closeNotifications();
        }
    });

    function closeNotifications() {
        notifyContainer.classList.remove("expand");
        notifyCardOpened = false;
    }

    function closeProfile() {
        profileContainer.classList.remove("expand");
        profileCardOpened = false;
    }
}
